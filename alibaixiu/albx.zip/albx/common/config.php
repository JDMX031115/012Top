<?php
define("DB_HOST", "127.0.0.1");
define("DB_USER", "root");
define("DB_PWD", "root");
define("DB_NAME", "db_baixiu");