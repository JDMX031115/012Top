<nav class="navbar">
  <button class="btn btn-default navbar-btn fa fa-bars"></button>
  <ul class="nav navbar-nav navbar-right">
    <li><a href="profile.php"><i class="fa fa-user"></i>个人中心</a></li>
    <li id='logout'><a href="javascript:void(0);"><i class="fa fa-sign-out"></i>退出</a></li>
  </ul>
</nav>
<script src="/static/assets/vendors/jquery/jquery.js"></script>
<script src="/static/assets/js/admin/_nav.js"></script>